var myTextOpacity = 255; //Changing variable to control opacity for mouse click

function setup() {
  createCanvas(800, 400);
}

function draw() {
  background(255, 192, 203);

  fill(204, 101, 192, 127);
  stroke(127, 63, 120);
  
  //Custom shape
  translate(width/3, height/2); //positioning the custom shape
  noStroke();
  //custom shape of a flower made by a bunch of ellipses using loops and rotate
  for (let i = 0; i < 10; i ++) {
    ellipse(0, 60, 40, 160);
    rotate(PI/5);
  }
    
  //Text Object - Adding some text that will be interactive
  textSize(40);
  fill(255,255,255,myTextOpacity);
  text("i [heart] poke", 200, 25);
  if(mouseIsPressed) //Gradually make the text disappear with each mouse click
  	myTextOpacity = myTextOpacity-10; //Decrease the opacity of text using variable declared
  	if (myTextOpacity<=0){ //Reset the opacity if it is no longer visible
  		myTextOpacity=255;
  	}  
    
    textSize(10);
    text("click me", 200, 60);
 
}